/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";

function Banner() {
  return (
    <section className="banner" id="banner">
      <div className="container">
        <div className="banner-wrapper">
          <div className="banner-img">
            <img src="/me.jpg" alt="" />
          </div>
          <div className="banner-content">
            <h6>Hello, I'm Sushant Kolekar</h6>
            <h3>Fullstack Web Developer</h3>
            <p>
            Solution-driven web developer adept at contributing to highly collaborative work environment and finding solutions.
            </p>
            <p>I've started my journey 1 year ago.I'm quietly confident,naturally curious, and perpetually working on my chops one design problem at a time.</p>
           
            <a className="btn" href="#projects">
              About Me
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Banner;
