/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";

function Footer() {
  return (
    <footer>
      <div className="container">
        <span className="logo">Portfolio.</span>
        <div className="links">
          <a href="https://www.linkedin.com/in/sushant-kolekar/">
            <i className="fab fa-linkedin"></i>
          </a>
          <a href="https://www.facebook.com/sushantdk.kolekar">
            <i className="fab fa-facebook"></i>
          </a>
          <a href="https://github.com/Sushantkolekar24">
            <i className="fab fa-github"></i>
          </a>
        </div>
        <p className="copyright">
          <i className="fas fa-heart"></i>
         Sushantdattatraykolekar24@gmail.com
          
        </p>
      </div>
    </footer>
  );
}

export default Footer;
