/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import { useState } from "react";

function Projects() {
  const [projects] = useState([
    {
      title: "QUIZ APP",
      img: "/projects/quiz.jpg",
      gLink: "https://github.com/Sushantkolekar24/Quiz-app.git",
   
      
    },
    {
      title: "WEATHER APP",
      img: "/projects/weather.png",
      gLink: "https://github.com/Sushantkolekar24/weather-app.git",
      
    },
    {
      title: "REACT PORTFOLIO",
      img: "/projects/react.jpg",
      gLink: "https://github.com/Sushantkolekar24/react-portfoilo",
      
    },
    {
      title: "Chat Gpt Clone",
      img: "/projects/chatGPT.jpg",
      gLink: "https://github.com/Sushantkolekar24/chat-Gpt-clone-MERN-STACK-",
      
    },
  
  ]);
  return (
    <section className="projects" id="projects">
      <div className="container">
        <div className="title">
          <h3>Featured Projects</h3>
          <a
            href="https://github.com/Sushantkolekar24"
            target="_blank"
            className="btn"
            rel="noreferrer"
          >
            View All
          </a>
        </div>
        <div className="projects-wrapper">
          {projects.map((project, i) => (
            <div className="project" key={i}>
              <div className="img-container">
                <img src={project.img} alt={project.title} />
              </div>
              <div className="description">
                <h4>{project.title}</h4>
               
                <div className="links">
                  <a href={project.gLink} target="_blank" rel="noreferrer">
                    <i className="fab fa-github"></i>
                  </a>
                 
                </div>
              </div>
            
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Projects;
