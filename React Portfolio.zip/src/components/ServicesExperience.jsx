import React, { useState } from "react";

function ServicesExperience() {
  const [services] = useState([
    {
      icon: "fa-paintbrush",
      title: "UI Design",
      desc: "I love to create beautiful products with delightful user experiences.",
      active: false,
    },
    {
      icon: "fa-pen-to-square",
      title: "Backend Developer",
      desc: "Node.js development services to build high-performance web apps",
      active: true,
    },
    {
      icon: "fa-ruler",
      title: "Database Management",
      desc: "Database management services - quicker, easier & smarter",
      active: false,
    },

 
  ]);
  return (
    <section className="services-experience">
      <div className="container">
        <div className="services" id="services">
          {services.map((service, i) => (
            <div
              key={i}
              className={`service ${service.active ? "active" : ""}`}
            >
              <i className={`fas ${service.icon}`} />
              <h3>{service.title}</h3>
              <p>{service.desc}</p>
              <button className="btn">Know More</button>
            </div>
          ))}
        </div>
        <div className="experiences" id="experiences">
          <div className="experience">
            <h3>1</h3>
            <p>Year Experience</p> 
            <p>I'm proud to have collaborated with some awesome comapanies</p>
            
          </div>
          <div className="portfolios">
            <div className="portfolio">
             
             <img src="/testbook.png" alt="" />

            </div>
            <div className="portfolio">
           <img src="/skillvertex1.jpg" alt="" srcset="" />
            </div>
            <div className="portfolio">
              <h4>3+</h4>
              <p>Completed Projects</p>
            </div>
            <div className="portfolio">
              <h4>01</h4>
              <p>Years Experience</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default ServicesExperience;
